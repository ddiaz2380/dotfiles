#!/usr/bin/env zsh
# vim:ft=zsh ts=2 sw=2 sts=2

_emotty_sets[emoji]="
  crystal_ball
  ghost
  jack_o_lantern
  see_no_evil_monkey
  hear_no_evil_monkey
  speak_no_evil_monkey
  smiling_cat_face_with_open_mouth
  extraterrestrial_alien
  rocket
  billiards
  bomb
  pill
  japanese_symbol_for_beginner
  direct_hit
  cyclone
  diamond_shape_with_a_dot_inside
  sparkle
  eight_spoked_asterisk
  eight_pointed_black_star
  "
